self.addEventListener("install", event => {
    console.log("test1")
    self.skipWaiting(); // 跳过等待￼
});

self.addEventListener("activate", event => {
    console.log("test2")
    clients.claim(); // 立即受控￼
});

self.addEventListener("fetch", event => {
    console.log("test3")
    if (/logo\.svg$/.test(event.request.url)) {
        console.log("test4")
        return event.respondWith(fetch("src/assets/black coal ball.jpg"));
    }
});

self.addEventListener("fetch", event => {
    console.log("test5")
    if (event.request.mode == "navigate") {
        console.log("test6")
        return event.respondWith(
            fetch(event.request).then(res => {
                if (res.status == 404) {
                    return fetch("custom404.html");
                }
                return res;
            })
        );
    }
});
